package com.example.springdemo01.service;

import com.example.springdemo01.vos.ResultVo;

public class IGridAqiBackServiceImpl implements IGridAqiBackService{
    @Override
    public ResultVo listAqiFeedbackPage() {
        return null;
    }
}
