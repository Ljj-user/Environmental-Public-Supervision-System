package com.example.springdemo01.service;

import com.example.springdemo01.vos.ResultVo;

public interface IGridMemberService {
    ResultVo getUsers();
    ResultVo getOne(String gmCode,String password);
    ResultVo getGridMemberByProvinceId(Integer provinceId);
}
