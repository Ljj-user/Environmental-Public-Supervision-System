package com.example.springdemo01.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.springdemo01.dao.IUserDao;
import com.example.springdemo01.pojo.User;
import com.example.springdemo01.vos.ResultVo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IUserServiceImpl implements IUserService{
    @Resource
    private IUserDao dao;//注入？？？

    @Override
    public ResultVo getUsers() {
        List<User> users = dao.selectList(null);
        return ResultVo.success("成功获取users数据",users);
    }

    @Override
    public ResultVo getOne() {
        QueryWrapper<User> qw = new QueryWrapper<>();
        qw.eq("username","zhangsan").eq("password","1234");
        User userone = dao.selectOne(qw);
        return ResultVo.success("成功获取一条消息",userone);
    }
}
