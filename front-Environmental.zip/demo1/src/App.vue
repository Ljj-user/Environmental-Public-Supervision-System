<script setup lang="ts">

  import {useRouter,RouterView} from "vue-router"
 

</script>

<template>
   <router-view/>
</template>

<style>


</style>
