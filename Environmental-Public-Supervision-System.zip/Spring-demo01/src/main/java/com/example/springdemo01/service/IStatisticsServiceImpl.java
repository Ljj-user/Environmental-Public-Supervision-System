package com.example.springdemo01.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.springdemo01.dao.StatisticsDao;
import com.example.springdemo01.pojo.Statistics;
import com.example.springdemo01.vos.ResultVo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IStatisticsServiceImpl implements IStatisticsService{
    @Resource
    private StatisticsDao dao;

    /**
     * 用
     * @param gm_id
     * @return
     */
    @Override
    public ResultVo getStatisticsById(String gm_id) {
        QueryWrapper<Statistics> qw = new QueryWrapper<>();
        qw.eq("gm_id",gm_id);
        List<Statistics> statistics = dao.selectList(qw);
//        if(statistics ==null || gm_id==null ){
//            return ResultVo.error("")
//        }
        return ResultVo.success("成功查询网格员反馈信息列表",statistics);
    }
    /**
     * public ResultVo getGridMemberByProvinceId(Integer provinceId) {
     *         QueryWrapper<GridMember> qw = new QueryWrapper<>();
     *         qw.eq("province_id",provinceId);
     *         List<GridMember> gridMembers = dao.selectList(qw);
     *         if(gridMembers == null || provinceId==null){
     *             return ResultVo.error("信息为空，无法查询");
     *         }
     *         return ResultVo.success("成功获取一条消息",gridMembers);
     *     }
     */
}
