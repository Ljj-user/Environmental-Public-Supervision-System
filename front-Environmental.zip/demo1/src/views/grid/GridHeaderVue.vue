<template>
  <img 
    src="@/assets/1.png" 
    alt="Grid Header Image"
    class="header-image"
  >
</template>

<script setup>
defineOptions({
  name: "GridHeaderVue"
})
</script>

<style scoped>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

.header-image {
  width: 500px;
  height: 280px;
  display: block;
}
</style>