package com.example.springdemo01.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springdemo01.pojo.GridMember;

public interface GridMemberDao extends BaseMapper<GridMember> {
}
