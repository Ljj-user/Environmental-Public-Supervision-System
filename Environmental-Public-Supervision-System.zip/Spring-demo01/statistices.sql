CREATE TABLE aqi (
                     aqi_id INT NOT NULL auto_increment COMMENT '空气质量增长列',
                     chinese_explainplain VARCHAR(10) COMMENT '空气质量指数级别文字表述',
                     aqi_explain VARCHAR(20) COMMENT '空气质量指数级别描述',
                     color VARCHAR(7) COMMENT '空气质量指数级别表示颜色',
                     health_impact VARCHAR(500) COMMENT '对健康影响情况',
                     take_steps VARCHAR(500) COMMENT '建议采取的措施',
                     so2_min INT COMMENT '本级二氧化硫浓度最小值',
                     so2_max INT COMMENT '本级二氧化硫浓度最大值',
                     co_min INT COMMENT '本级一氧化碳浓度最小值',
                     co_max INT COMMENT '本级一氧化碳浓度最大值',
                     spm_min INT COMMENT '本级易悬浮颗粒物浓度最小值',
                     spm_max INT COMMENT '本级易悬浮颗粒物浓度最大值',
                     remarks VARCHAR(100) COMMENT '备注',
                     PRIMARY KEY (aqi_id)
) COMMENT = '空气质量指数级别表';



CREATE TABLE statistics (
                            id INT NOT NULL AUTO_INCREMENT COMMENT 'id',
                            province_id INT COMMENT '所属省编号',
                            city_id INT COMMENT '所属区域编号',
                            address VARCHAR(200) COMMENT '传感器所在区域详细地址',
                            so2_level INT COMMENT '大气污染 - 二氧化硫浓度（单位：μg/m³）',
                            so2_value INT COMMENT '大气污染 - 氮氧化物浓度（单位：μg/m³）',
                            co_value INT COMMENT '大气污染 - 一氧化碳浓度（单位：μg/m³）',
                            co_level INT COMMENT '大气污染 - 臭氧浓度（单位：μg/m³）',
                            spm_value INT COMMENT '空气中细颗粒物污染值',
                            spm_level INT COMMENT '空气中可吸入颗粒物污染值',
                            aqi_id INT COMMENT '空气质量指数级别',
                            confirm_data VARCHAR(20) COMMENT '确认日期',
                            confirm_time VARCHAR(20) COMMENT '确认时间',
                            gm_id VARCHAR(11) NOT NULL COMMENT '所属网格员编号',
                            fd_id VARCHAR(20) COMMENT '公众监督员电话号码',
                            information VARCHAR(400) COMMENT '反馈信息描述',
                            remarks VARCHAR(20) COMMENT '备注',
                            PRIMARY KEY (id),
    -- 关联 grid_province 表，假设其主键是 id
                            FOREIGN KEY (province_id) REFERENCES grid_province(province_id) ON DELETE SET NULL ON UPDATE CASCADE,
    -- 关联 grid_city 表，假设其主键是 id
                            FOREIGN KEY (city_id) REFERENCES grid_city(city_id) ON DELETE SET NULL ON UPDATE CASCADE,
    -- 关联 aqi_levels 表（或实际存在的空气质量级别表），假设主键是 id
                            FOREIGN KEY (aqi_id) REFERENCES aqi(aqi_id) ON DELETE SET NULL ON UPDATE CASCADE,
    -- 关联 supervisor 表，假设其主键是 phone（公众监督员电话）
                            FOREIGN KEY (gm_id) REFERENCES grid_member(gm_id)  ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='空气质量监测系统设计表';



SHOW CREATE TABLE grid_member;
SHOW CREATE TABLE statistics;
SHOW CREATE TABLE grid_member;