package com.example.springdemo01.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
@Data
@TableName("statistics") // 表名建议小写，与数据库保持一致
public class Statistics {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id; // 自增主键ID

    @TableField("province_id")
    private Integer provinceId; // 所属省编号

    @TableField("city_id")
    private Integer cityId; // 所属市编号

    @TableField("address")
    private String address; // 详细地址

    @TableField("so2_level")
    private Integer so2Level; // 二氧化硫浓度等级

    @TableField("so2_value")
    private Integer so2Value; // 二氧化硫浓度值

    @TableField("co_value")
    private Integer coValue; // 一氧化碳浓度值

    @TableField("co_level")
    private Integer coLevel; // 一氧化碳浓度等级

    @TableField("spm_value")
    private Integer spmValue; // 细颗粒物污染值

    @TableField("spm_level")
    private Integer spmLevel; // 可吸入颗粒物污染值

    @TableField("aqi_id")
    private Integer aqiId; // 空气质量指数级别

    @TableField("confirm_data")
    private String confirmData; // 确认日期

    @TableField("confirm_time")
    private String confirmTime; // 确认时间

    @TableField("gm_id")
    private String gmId; // 网格员编号(外键)

    @TableField("fd_id")
    private String fdId; // 公众监督员电话

    @TableField("information")
    private String information; // 反馈信息描述

    @TableField("remarks")
    private String remarks; // 备注信息
}
