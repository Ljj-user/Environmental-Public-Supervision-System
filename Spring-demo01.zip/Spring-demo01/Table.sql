CREATE TABLE `admins` (
                          `admin_id` INT AUTO_INCREMENT COMMENT '系统管理员编号(主键，自增列)',
                          `admin_code` VARCHAR(20) NOT NULL COMMENT '管理员登录编码',
                          `password` VARCHAR(20) NOT NULL COMMENT '登录密码',
                          `remarks` VARCHAR(200) COMMENT '备注',
                          PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统管理员表';


CREATE TABLE `supervisor` (
                              `tel_id` VARCHAR(11) NOT NULL COMMENT '公众监督员编号（手机号码，主键）',
                              `password` VARCHAR(20) NOT NULL COMMENT '登录密码',
                              `real_name` VARCHAR(20) NOT NULL COMMENT '公众监督员真实姓名',
                              `birthday` VARCHAR(20) COMMENT '公众监督员出生日期',
                              `sex` INT NOT NULL DEFAULT 1 COMMENT '公众监督员性别（1:男，0:女）',
                              `remarks` VARCHAR(100) COMMENT '备注',
                              PRIMARY KEY (`tel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众监督员表';



CREATE TABLE `grid_member` (
                               `gm_id` VARCHAR(11) NOT NULL COMMENT '网格员手机号码（主键）',
                               `gm_name` VARCHAR(20) NOT NULL COMMENT '网格员名称',
                               `gm_code` VARCHAR(20) NOT NULL COMMENT '网格员登录编码',
                               `password` VARCHAR(20) NOT NULL COMMENT '登录密码',
                               `province_id` INT NOT NULL COMMENT '网格区域：省编号（外键）',
                               `city_id` INT NOT NULL COMMENT '网格区域：市编号（外键）',
                               `tel` VARCHAR(20) NOT NULL COMMENT '联系电话',
                               `state` INT NOT NULL DEFAULT  0 COMMENT '网格员状态（0:可工作，1:临时抽调，2:休假，3:其它）',
                               `remarks` VARCHAR(200) COMMENT '备注',
                               PRIMARY KEY (`gm_id`),
                               FOREIGN KEY (`province_id`) REFERENCES `grid_province`(`province_id`),
                               FOREIGN KEY (`city_id`) REFERENCES `grid_city`(`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='空气质量监测网格员表';

CREATE TABLE `grid_province` (
                                 `province_id` INT NOT NULL AUTO_INCREMENT COMMENT '系统网格覆盖省区域编号（主键，自增长列）',
                                 `province_name` VARCHAR(20) NOT NULL COMMENT '系统网格覆盖省区域名称',
                                 `province_abbr` VARCHAR(2) NOT NULL COMMENT '系统网格覆盖省区域简称',
                                 `remarks` VARCHAR(200) COMMENT '备注',
                                 PRIMARY KEY (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统网格覆盖省区域表';

CREATE TABLE `grid_city` (
                             `city_id` INT NOT NULL AUTO_INCREMENT COMMENT '系统网格覆盖市区域编号（主键，自增长列）',
                             `city_name` VARCHAR(20) NOT NULL COMMENT '系统网格覆盖市区域名称',
                             `province_id` INT NOT NULL COMMENT '所属省区域编号（外键）',
                             `remarks` VARCHAR(200) COMMENT '备注',
                             PRIMARY KEY (`city_id`),
                             FOREIGN KEY (`province_id`) REFERENCES `grid_province`(`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统网格覆盖市区域表';
