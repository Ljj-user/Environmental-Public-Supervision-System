-- 管理员数据示例
INSERT INTO `admins` (`admin_code`, `password`, `remarks`) VALUES
                                                               ('admin001', 'password123', '系统超级管理员'),
                                                               ('admin002', 'securepass', '负责用户管理'),
                                                               ('admin003', 'test1234', '负责数据审核'),
                                                               ('admin004', 'admin123', '技术支持管理员'),
                                                               ('admin005', 'newpassword', '临时管理员');


-- 公众监督员数据示例
INSERT INTO `supervisor` (`tel_id`, `password`, `real_name`, `birthday`, `sex`, `remarks`) VALUES
                                                                                               ('13000000001', 'pass1234', '张三', '1990-01-15', 1, '空气质量关注者'),
                                                                                               ('13000000002', 'secure5678', '李四', '1985-03-22', 1, '环保志愿者'),
                                                                                               ('13000000003', 'test9876', '王五', '1995-07-08', 0, '社区环保积极分子'),
                                                                                               ('13000000004', 'user4321', '赵六', '1988-12-10', 1, '教师，关注校园周边环境'),
                                                                                               ('13000000005', 'newpass', '钱七', '1992-05-20', 0, '退休人员，热心环保事业'),
                                                                                               ('13000000006', 'abc123', '孙八', '1987-09-14', 1, '企业员工，关注工业污染'),
                                                                                               ('13000000007', 'pass7890', '周九', '1993-04-05', 0, '大学生，参与环保社团'),
                                                                                               ('13000000008', 'secure2025', '吴十', '1986-11-28', 1, '摄影师，记录城市环境变化'),
                                                                                               ('13000000009', 'testuser', '郑十一', '1991-08-17', 0, '医生，关注空气污染对健康影响'),
                                                                                               ('13000000010', 'finalpass', '陈十二', '1989-02-23', 1, '自由职业者，长期监测社区环境');

INSERT INTO `grid_province` (`province_name`, `province_abbr`, `remarks`) VALUES
                                                                              ('北京市', '京', '中国首都，直辖市'),
                                                                              ('上海市', '沪', '中国经济中心，直辖市'),
                                                                              ('广东省', '粤', '南部沿海经济强省'),
                                                                              ('江苏省', '苏', '东部沿海发达省份'),
                                                                              ('浙江省', '浙', '民营经济活跃省份'),
                                                                              ('山东省', '鲁', '北方经济大省'),
                                                                              ('四川省', '川', '西南地区重要省份'),
                                                                              ('湖北省', '鄂', '中部地区重要省份'),
                                                                              ('湖南省', '湘', '长江中游省份'),
                                                                              ('河南省', '豫', '中原地区人口大省');

-- 北京市
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('北京市', 1, '首都核心城区'),
                                                                    ('密云区', 1, '北京市远郊区');

-- 上海市
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('上海市', 2, '上海主城区'),
                                                                    ('浦东新区', 2, '上海市重要开发区');

-- 广东省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('广州市', 3, '广东省省会'),
                                                                    ('深圳市', 3, '经济特区，创新中心');

-- 江苏省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('南京市', 4, '江苏省省会'),
                                                                    ('苏州市', 4, '经济发达地级市');

-- 浙江省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('杭州市', 5, '浙江省省会，互联网产业发达'),
                                                                    ('宁波市', 5, '重要港口城市');

-- 山东省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('济南市', 6, '山东省省会'),
                                                                    ('青岛市', 6, '沿海重要城市');

-- 四川省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('成都市', 7, '四川省省会'),
                                                                    ('绵阳市', 7, '科技城');

-- 湖北省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('武汉市', 8, '湖北省省会，中部枢纽'),
                                                                    ('宜昌市', 8, '长江三峡所在地');

-- 湖南省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('长沙市', 9, '湖南省省会'),
                                                                    ('株洲市', 9, '重要工业城市');

-- 河南省
INSERT INTO `grid_city` (`city_name`, `province_id`, `remarks`) VALUES
                                                                    ('郑州市', 10, '河南省省会'),
                                                                    ('洛阳市', 10, '历史文化名城');


INSERT INTO `grid_member`
(`gm_id`, `gm_name`, `gm_code`, `password`, `province_id`, `city_id`, `tel`, `state`, `remarks`)
VALUES

-- 北京市（province_id=1，city_id=1/2）
('13500000001', '王建国', 'BJ_GRID01', 'grid@123', 1, 1, '13500000001', 0, '负责北京市朝阳区巡查'),
('13500000002', '李红梅', 'BJ_GRID02', 'grid@456', 1, 2, '13500000002', 0, '负责密云区水库周边监测'),

-- 上海市（province_id=2，city_id=3/4）
('13600000003', '张宏伟', 'SH_GRID01', 'sh_grid#', 2, 3, '13600000003', 1, '临时抽调至黄浦区应急任务'),
('13600000004', '陈雨桐', 'SH_GRID02', 'sh_grid$', 2, 4, '13600000004', 0, '负责浦东新区工业园区巡检'),

-- 广东省（province_id=3，city_id=5/6）
('13700000005', '林浩然', 'GD_GRID01', 'gd_pass1', 3, 5, '13700000005', 0, '广州市天河区餐饮油烟治理'),
('13700000006', '吴小敏', 'GD_GRID02', 'gd_pass2', 3, 6, '13700000006', 2, '休假中（9月1日返岗）'),

-- 江苏省（province_id=4，city_id=7/8）
('13800000007', '周明远', 'JS_GRID01', 'js_grid!', 4, 7, '13800000007', 0, '南京市玄武区工地扬尘管控'),
('13800000008', '徐佳琪', 'JS_GRID02', 'js_grid@', 4, 8, '13800000008', 3, '借调至省环保厅培训'),

-- 浙江省（province_id=5，city_id=9/10）
('13900000009', '郑海洋', 'ZJ_GRID01', 'zj_grid#', 5, 9, '13900000009', 0, '杭州市西湖区景区空气质量监测'),
('13900000010', '吕文静', 'ZJ_GRID02', 'zj_grid$', 5, 10, '13900000010', 1, '支援宁波市重污染天气应急');


INSERT INTO aqi (
    chinese_explainplain,
    aqi_explain,
    color,
    health_impact,
    take_steps,
    so2_min,
    so2_max,
    co_min,
    co_max,
    spm_min,
    spm_max,
    remarks
) VALUES (
             '优',
             '空气质量令人满意',
             '#00E400',  -- 绿色
             '空气质量令人满意，基本无空气污染',
             '各类人群可正常活动',
             0,
             50,
             0,
             2,
             0,
             35,
             '中国空气质量标准（GB 3095-2012）'
         );



-- 插入示例数据
INSERT INTO statistics (province_id, city_id, address, so2_level, so2_value, co_value, co_level, spm_value, spm_level, aqi_id, confirm_data, confirm_time, gm_id, fd_id, information, remarks)
VALUES
-- 北京监测点数据
(1, 1, '北京市海淀区中关村南大街5号', 15, 40, 1.2, 80, 35, 60, 1, '2025-06-09', '12:00:00', '1', '13800138001', '空气质量良好，无明显污染', '正常'),
-- 上海监测点数据
(2, 3, '上海市浦东新区张江高科技园区', 10, 35, 0.9, 75, 40, 70, 1, '2025-06-09', '12:15:00', '1', '13900139001', '轻度污染，建议敏感人群减少户外活动', '需关注'),
-- 广州监测点数据
(3, 5, '广东省广州市天河区珠江新城', 8, 30, 0.8, 65, 30, 55, 1, '2025-06-09', '12:30:00', '1', '13700137001', '空气质量优，适合户外活动', '正常');
