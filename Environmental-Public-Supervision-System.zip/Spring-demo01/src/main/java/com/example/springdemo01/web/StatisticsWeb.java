package com.example.springdemo01.web;

import com.example.springdemo01.service.IGridMemberService;
import com.example.springdemo01.service.IStatisticsService;
import com.example.springdemo01.vos.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("*")
@RestController
@RequestMapping("/IStatistics")
public class StatisticsWeb {
    @Autowired
    private IStatisticsService service;

    /**
     * 通过gm_id返回相关网格员的statis信息；
     * @param gm_id
     * @return
     */
    @RequestMapping("/getStatisticsByGm_id")
    public ResultVo getStatisticsById(String gm_id){
        return service.getStatisticsById(gm_id);
    }

}
