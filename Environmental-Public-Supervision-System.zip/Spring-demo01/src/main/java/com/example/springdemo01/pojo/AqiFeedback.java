package com.example.springdemo01.pojo;

public class AqiFeedback {

}
