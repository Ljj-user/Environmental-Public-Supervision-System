package com.example.springdemo01.web;

import com.example.springdemo01.service.IGridMemberService;
import com.example.springdemo01.vos.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController("/gridMember")
public class GridMemberWeb {
    @Autowired
    private IGridMemberService service;


    @RequestMapping("/getAll")
    public ResultVo getUsrs(){
        return service.getUsers();
    }

    @RequestMapping("/getGridMemberByCodeByPass")
    public ResultVo getOne(String gmCode,String password){
        return service.getOne(gmCode,password);
    }

    @RequestMapping("/getGridMemberByProvinceId")
    public ResultVo getGridMemberByProvinceId(Integer provinceId){
        return service.getGridMemberByProvinceId(provinceId);
    }

}
