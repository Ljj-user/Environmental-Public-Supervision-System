package com.example.springdemo01.vos;

import lombok.Data;

//返回web层返回数据类型
@Data
public class ResultVo<T> {
    private Integer code;
    private String message;
    private T t;

    public ResultVo(Integer code, String message, T t) {
        this.code = code;
        this.message = message;
        this.t = t;
    }

    public ResultVo(Integer code, T t) {
        this.code = code;
        this.t = t;
    }

    public ResultVo(String message, T t) {
        this.message = message;
        this.t = t;
    }

    public static <T> ResultVo success(T t){
        return new ResultVo<T>(6000,"成功",t);
    }

    public static <T> ResultVo success(String message,T t){
        return new ResultVo<T>(6000,message,t);
    }

    public static <T> ResultVo error(){
        return new ResultVo(7000,"error");
    }

    public static <T> ResultVo error(String message){
        return new ResultVo(7000,message);
    }

}
