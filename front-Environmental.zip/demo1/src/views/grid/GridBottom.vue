<template>
  <div id="bottom">
    <img src="@/assets/2.png" width="500" alt="">
  </div>
</template>

<script setup name="GridBottom">

</script>

<style scoped>
#bottom{
  position:absolute;
  bottom:-227px;
}
</style>