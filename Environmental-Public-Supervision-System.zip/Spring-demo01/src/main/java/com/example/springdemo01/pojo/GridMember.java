package com.example.springdemo01.pojo;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;

/**
 * 空气质量监测网格员实体类
 */
@Data
@TableName("grid_member")
public class GridMember implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 网格员手机号码（主键）
     */
    @TableId(value = "gm_id", type = IdType.INPUT)
    private String gmId;

    /**
     * 网格员名称
     */
    @TableField("gm_name")
    private String gmName;

    /**
     * 网格员登录编码
     */
    @TableField("gm_code")
    private String gmCode;

    /**
     * 登录密码
     */
    @TableField("password")
    private String password;

    /**
     * 网格区域：省编号（外键）
     */
    @TableField("province_id")
    private Integer provinceId;

    /**
     * 网格区域：市编号（外键）
     */
    @TableField("city_id")
    private Integer cityId;

    /**
     * 联系电话
     */
    @TableField("tel")
    private String tel;

    /**
     * 网格员状态（0:可工作，1:临时抽调，2:休假，3:其它）
     */
    @TableField("state")
    private Integer state;

    /**
     * 备注
     */
    @TableField("remarks")
    private String remarks;
}