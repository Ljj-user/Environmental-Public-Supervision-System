<script setup lang="ts">
  import {ref,inject} from "vue"
  import {useRouter} from "vue-router"
  import GridHeaderVue from "./GridHeaderVue.vue"
  import GridBottomVue from "./GridBottom.vue"
  const axios = inject("axios")
  const router=useRouter()
  const gmLogin = ()=>{
  axios.get("http://127.0.0.1:8080/gridMember/getGridMemberByCodeByPass",{
    params:{
      gmCode:gridMember.value.gmCode,
      password:gridMember.value.password
    }
  }).then(e=>{
    console.log(e)
    if(e.data.code==6000){
      router.push("/gridBack")
    }else{
      alert(e.data.t)
    }
  })
  }
  let gridMember=ref({
    gmCode:"",
    password:""
  })


</script>

<template>
  <grid-header-vue/>
  <h2>公众监督平台-网格员端</h2>
  {{gridMember}}
  <form action="">
    <input type="text" name="gmCode" v-model="gridMember.gmCode" placeholder="请输入登录编码">
    <input type="password" name="password" v-model="gridMember.password" placeholder="请输入密码">
    <input type="button" @click="gmLogin" value="登录">

</form>
<grid-bottom-vue/>

</template>

<style>
form{
  width:70%;
  margin:auto;
  text-align:center;
  margin-bottom:20px;
}
form input{
   width:70%;
   height:40px;
   margin-bottom:40px;
   border-radius:40px;
}
*{
  padding:0px;
  margin:0px;
}

h2{
  /*text-decoration:underline;*/
  width:70%;
  border-bottom:solid 2px blue;
  color:blue;
  margin:auto;
  text-align:center;
  margin-bottom:20px;
}
form input:nth-child(3){
  background-color:aqua;
  font-size:30px;
}

</style>

