package com.example.springdemo01.service;

import com.example.springdemo01.vos.ResultVo;

public interface IUserService {
    ResultVo getUsers();
    ResultVo getOne();
}
