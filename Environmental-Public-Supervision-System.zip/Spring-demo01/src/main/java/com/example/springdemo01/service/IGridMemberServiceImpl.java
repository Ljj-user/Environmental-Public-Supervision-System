package com.example.springdemo01.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.springdemo01.dao.GridMemberDao;
import com.example.springdemo01.pojo.GridMember;
import com.example.springdemo01.pojo.User;
import com.example.springdemo01.vos.ResultVo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IGridMemberServiceImpl implements IGridMemberService{
    @Resource
    private GridMemberDao dao;//注入？？？
    @Override
    public ResultVo getUsers() {
        List<GridMember> gridMember = dao.selectList(null);
        return ResultVo.success("成功获取users数据",gridMember);
    }

    @Override
    public ResultVo getOne(String gmCode,String password) {
        QueryWrapper<GridMember> qw = new QueryWrapper<>();
        qw.eq("gm_code",gmCode).eq("password",password);
        GridMember gridMember = dao.selectOne(qw);
        if(gridMember == null){
            return ResultVo.error("用户信息有误不能登录");
        }
        return ResultVo.success("成功获取一条消息",gridMember);
    }

    @Override
    public ResultVo getGridMemberByProvinceId(Integer provinceId) {
        QueryWrapper<GridMember> qw = new QueryWrapper<>();
        qw.eq("province_id",provinceId);
        List<GridMember> gridMembers = dao.selectList(qw);
        if(gridMembers == null || provinceId==null){
            return ResultVo.error("信息为空，无法查询");
        }
        return ResultVo.success("成功获取一条消息",gridMembers);
    }
}
