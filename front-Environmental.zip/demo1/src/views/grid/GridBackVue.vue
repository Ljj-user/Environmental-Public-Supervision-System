<template>
  <grid-header-vue />
  <grid-bottom-vue />

  <div class="grid-back-container">
    <main class="content-area">
      <h1>网格员后台管理</h1>
      <p>欢迎使用网格员管理系统</p >
    </main>
    
  </div>
</template>

<script setup lang="ts" name="GridBackVue">
// 导入组件
import GridHeaderVue from "./GridHeaderVue.vue";
import GridBottomVue from "./GridBottom.vue";

</script>

<style scoped>

</style>