package com.example.springdemo01.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springdemo01.pojo.Statistics;

public interface StatisticsDao extends BaseMapper<Statistics> {
}
