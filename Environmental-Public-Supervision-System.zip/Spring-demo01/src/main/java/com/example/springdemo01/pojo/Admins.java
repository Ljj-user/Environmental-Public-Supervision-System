package com.example.springdemo01.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("admins")
@Data
public class Admins {
    @TableId(value = "admin_id",type = IdType.AUTO)
    private int admin_id;
    @TableField("admin_code")
    private String admin_code;
    @TableField("password")
    private String password;
    @TableField("remarks")
    private String remarks;
}
