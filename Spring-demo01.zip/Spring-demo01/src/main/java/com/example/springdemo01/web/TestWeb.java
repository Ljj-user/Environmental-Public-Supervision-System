package com.example.springdemo01.web;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.springdemo01.dao.AdminsDao;
import com.example.springdemo01.dao.GridMemberDao;
import com.example.springdemo01.dao.IUserDao;
import com.example.springdemo01.pojo.Admins;
import com.example.springdemo01.pojo.GridMember;
import com.example.springdemo01.pojo.User;
import com.example.springdemo01.service.IUserService;
import com.example.springdemo01.vos.ResultVo;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestWeb {
    @Autowired
    private IUserService service;
    @Resource
    private AdminsDao adminsDao;
    @Resource
    private GridMemberDao gridMemberDao;

    @RequestMapping("/a")
    public String a(){
        return "abcd";
    }

    @RequestMapping("/b")
    public String b(){
        return "1234";
    }

    @RequestMapping("/user")
    public ResultVo user(){
        return service.getUsers();
    }

    @RequestMapping("/userone")
    public ResultVo userone(){
        return service.getOne();
    }

    @RequestMapping("/admin")
    public List<Admins> admin(){
        //一个表有多个对象，  一个类可以创建多个对象；
        List<Admins> admins = adminsDao.selectList(null);
        return admins;
    }

    @RequestMapping("/gridMembers")
    public List<GridMember> gridMembers() {
        // 查询所有网格员信息
        List<GridMember> gridMembers = gridMemberDao.selectList(null);
        return gridMembers;
    }

}
